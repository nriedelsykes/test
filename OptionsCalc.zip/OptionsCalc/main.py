import pandas as pd
import utlis
from datetime import datetime


trade_history = pd.read_excel('ExampleTradeHistory.xlsx')

# By symbol
spy_trades = utlis.filter_by_symbol(trade_history, "SPY")
spy_total = utlis.sum_net_price(spy_trades)
print("Spy total: ${:,.2f}".format(spy_total))

# By option
call_options = utlis.filter_by_optiontype(trade_history, "CALL")
call_total =utlis.sum_net_price(call_options)
print("Call total: ${:,.2f}".format(call_total))

# By date range
date_options = utlis.filter_by_daterange(trade_history, datetime(2020, 8, 24))
date_total = utlis.sum_net_price(date_options)
print("Date total: ${:,.2f}".format(date_total))

