import pandas as pd
from datetime import datetime
from decimal import Decimal



def filter_by_symbol(data_frame : pd.DataFrame, symbol : str):
    """Filters provided dataset for specified stock symbol"""
    return data_frame[data_frame.apply(lambda x: x['Symbol'] == symbol.upper(), axis=1)]

def filter_by_optiontype(data_frame : pd.DataFrame, option_type : str):
    """Filters provided dataset for specified option category"""
    if (option_type.upper() != 'CALL' and option_type.upper() != 'PUT'):
        raise ValueError("Invalid option type supplied")
    
    return data_frame[data_frame.apply(lambda x: x['Type'] == option_type.upper(), axis=1)]

def filter_by_daterange(data_frame: pd.DataFrame, start_date: datetime, end_date: datetime = datetime.now()):
    """Filters provided dataset specified date range"""
    return data_frame[data_frame.apply(lambda x: pd.to_datetime(x['ExecTime']) > start_date
                                        and pd.to_datetime(x['ExecTime']) < end_date, axis=1)]

def sum_net_price(data_frame: pd.DataFrame):
    """True profilt/loss of provided dataset"""
    sum = 0
    for index, row in data_frame.iterrows():
        sum += 100*int(row['Qty'])*Decimal(row['NetPrice'])
    
    return sum
